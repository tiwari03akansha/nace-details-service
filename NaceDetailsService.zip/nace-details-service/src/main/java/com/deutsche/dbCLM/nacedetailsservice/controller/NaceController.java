package com.deutsche.dbCLM.nacedetailsservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.deutsche.dbCLM.nacedetailsservice.model.Nace;
import com.deutsche.dbCLM.nacedetailsservice.service.NaceService;
import com.deutsche.dbCLM.nacedetailsservice.util.CSVHelper;

@RestController
@RequestMapping("/dbCLM/nace")
public class NaceController {

	@Autowired
	NaceService fileService;

	@RequestMapping(value = "/saveDetails", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public void putNaceDetails(@RequestParam("file") MultipartFile file) {

		if (CSVHelper.hasCSVFormat(file)) {

			fileService.save(file);

		}

	}

	@RequestMapping(value = "/getDetails/{id}", method = RequestMethod.GET)
	public Nace getNaceDetails(@PathVariable("id") Long id) {

		Optional<Nace> naceOptional = fileService.getDetailsbyId(id);

		if (naceOptional.isEmpty()) {
			throw new RuntimeException("Unable to Find data for ");
		}

		return naceOptional.get();
	}
}
