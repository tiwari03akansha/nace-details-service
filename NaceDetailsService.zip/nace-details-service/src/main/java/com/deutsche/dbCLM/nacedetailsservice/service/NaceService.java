package com.deutsche.dbCLM.nacedetailsservice.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.deutsche.dbCLM.nacedetailsservice.model.Nace;
import com.deutsche.dbCLM.nacedetailsservice.repository.NaceRepository;
import com.deutsche.dbCLM.nacedetailsservice.util.CSVHelper;

@Service
public class NaceService {

	
	 @Autowired
	  NaceRepository repository;

	  public void save(MultipartFile file) {
	    try {
	      List<Nace> naces = CSVHelper.csvToNaces(file.getInputStream());
	      repository.saveAll(naces);
	    } catch (IOException e) {
	      throw new RuntimeException("fail to store csv data: " + e.getMessage());
	    }
	  }

	  public Optional<Nace> getDetailsbyId(Long id) {
	    return repository.findById(id);
	  }
}
