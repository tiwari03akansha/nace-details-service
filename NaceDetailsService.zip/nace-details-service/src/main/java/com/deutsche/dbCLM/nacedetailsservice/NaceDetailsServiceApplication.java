package com.deutsche.dbCLM.nacedetailsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NaceDetailsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NaceDetailsServiceApplication.class, args);
	}

}
