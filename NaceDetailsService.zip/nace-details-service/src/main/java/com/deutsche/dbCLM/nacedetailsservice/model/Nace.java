package com.deutsche.dbCLM.nacedetailsservice.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "nace_details")
public class Nace {
	@Id
	@Column(name = "order_Id")
    private long orderId;
	
	@Column(name = "level")
    private int level;
	
	@Column(name = "code")
    private String code;
	
	@Column(name = "parent")
    private String parent;
	
	@Column(name = "desc")
    private String desc;
	
	@Column(name = "item_Includes")
    private String itemIncludes;
	
	@Column(name = "also_Includes")
    private String alsoIncludes;
	
	@Column(name = "rulings")
    private String rulings;
	
	@Column(name = "item_Excludes")
    private String itemExcludes;
	
	@Column(name = "ref_ISIC")
    private String refISIC;

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getParent() {
		return parent;
	}

	public void setParent(String parent) {
		this.parent = parent;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getItemIncludes() {
		return itemIncludes;
	}

	public void setItemIncludes(String itemIncludes) {
		this.itemIncludes = itemIncludes;
	}

	public String getAlsoIncludes() {
		return alsoIncludes;
	}

	public void setAlsoIncludes(String alsoIncludes) {
		this.alsoIncludes = alsoIncludes;
	}

	public String getRulings() {
		return rulings;
	}

	public void setRulings(String rulings) {
		this.rulings = rulings;
	}

	public String getItemExcludes() {
		return itemExcludes;
	}

	public void setItemExcludes(String itemExcludes) {
		this.itemExcludes = itemExcludes;
	}

	public String getRefISIC() {
		return refISIC;
	}

	public void setRefISIC(String refISIC) {
		this.refISIC = refISIC;
	}
	
public Nace() {
		
	}

public Nace(long orderId, int level, String code, String parent, String desc, String itemIncludes, String alsoIncludes,
		String rulings, String itemExcludes, String refISIC) {
	super();
	this.orderId = orderId;
	this.level = level;
	this.code = code;
	this.parent = parent;
	this.desc = desc;
	this.itemIncludes = itemIncludes;
	this.alsoIncludes = alsoIncludes;
	this.rulings = rulings;
	this.itemExcludes = itemExcludes;
	this.refISIC = refISIC;
}

@Override
public String toString() {
	return "Nace [orderId=" + orderId + ", level=" + level + ", code=" + code + ", parent=" + parent + ", desc=" + desc
			+ ", itemIncludes=" + itemIncludes + ", alsoIncludes=" + alsoIncludes + ", rulings=" + rulings
			+ ", itemExcludes=" + itemExcludes + ", refISIC=" + refISIC + "]";
}



	

}
