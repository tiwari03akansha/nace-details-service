package com.deutsche.dbCLM.nacedetailsservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface NaceRepository extends JpaRepository{

}
