package com.deutsche.dbCLM.nacedetailsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NaceDetailsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
